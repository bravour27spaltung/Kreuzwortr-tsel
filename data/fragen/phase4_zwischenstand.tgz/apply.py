import sys, json
"""apply.py <batchfile> <json-dict>  – ersetzt/ergänzt Fragen."""
p=sys.argv[1]; fix=json.loads(open(sys.argv[2]).read())
lines=open(p).read().splitlines(); out=[]; seen=set()
for l in lines:
    w,c=l.split('|',1); seen.add(w); out.append(f"{w}|{fix.get(w,c)}")
for w,c in fix.items():
    if w not in seen: out.append(f"{w}|{c}")
open(p,'w').write('\n'.join(out)+'\n')
